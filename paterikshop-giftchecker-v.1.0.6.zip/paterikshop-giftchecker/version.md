# NitroGiftChecker Version Log

## Current Version

**1.0.6**

---

- Added multi-language support (English & Dutch) for all prompts.
- Added feedback prompt at the end of the script.
- Improved version check logic and user experience.
